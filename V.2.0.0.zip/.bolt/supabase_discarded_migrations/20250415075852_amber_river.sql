-- Drop existing table if it exists
DROP TABLE IF EXISTS platform_connections CASCADE;

-- Create platform_connections table with improved structure
CREATE TABLE platform_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  platform text NOT NULL,
  config jsonb NOT NULL,
  status text NOT NULL DEFAULT 'active',
  last_sync_at timestamptz,
  sync_status jsonb DEFAULT '{}'::jsonb,
  error_log jsonb[] DEFAULT ARRAY[]::jsonb[],
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  
  -- Add unique constraint to prevent duplicate connections
  UNIQUE(user_id, platform),
  
  -- Add config validation for different platforms
  CONSTRAINT platform_connections_config_check CHECK (
    CASE platform
      WHEN 'tiktok' THEN (
        config ? 'access_token' AND
        config ? 'refresh_token' AND
        config ? 'expires_in' AND
        config ? 'expires_at' AND
        config ? 'store_id' AND
        config ? 'store_name' AND
        config ? 'region' AND
        config ? 'open_id'
      )
      WHEN 'shopee' THEN (
        config ? 'access_token' AND
        config ? 'refresh_token' AND
        config ? 'expires_at' AND
        config ? 'shop_id'
      )
      WHEN 'lazada' THEN (
        config ? 'access_token' AND
        config ? 'refresh_token' AND
        config ? 'expires_at' AND
        config ? 'seller_id'
      )
      ELSE true
    END
  ),

  -- Add status validation
  CONSTRAINT valid_status CHECK (status IN ('active', 'inactive', 'error', 'expired')),

  -- Add platform validation
  CONSTRAINT valid_platform CHECK (platform IN ('tiktok', 'shopee', 'lazada')),

  -- Ensure expires_at is in the future on insert
  CONSTRAINT future_expiry CHECK (
    (config->>'expires_at')::bigint > EXTRACT(EPOCH FROM NOW())::bigint * 1000
  )
);

-- Enable RLS
ALTER TABLE platform_connections ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage their own platform connections"
  ON platform_connections
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for better query performance
CREATE INDEX idx_platform_connections_user_platform 
  ON platform_connections(user_id, platform);

CREATE INDEX idx_platform_connections_status
  ON platform_connections(status);

CREATE INDEX idx_platform_connections_last_sync
  ON platform_connections(last_sync_at);

-- Create GIN index for jsonb fields
CREATE INDEX idx_platform_connections_config
  ON platform_connections USING GIN (config);

CREATE INDEX idx_platform_connections_metadata
  ON platform_connections USING GIN (metadata);

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_platform_connection_timestamps()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  
  -- Update error_log if status changes to error
  IF NEW.status = 'error' AND OLD.status != 'error' THEN
    NEW.error_log = array_append(
      COALESCE(OLD.error_log, ARRAY[]::jsonb[]),
      jsonb_build_object(
        'timestamp', extract(epoch from now()),
        'message', COALESCE(NEW.metadata->>'error_message', 'Unknown error'),
        'previous_status', OLD.status
      )
    );
  END IF;

  -- Update sync_status on successful sync
  IF NEW.last_sync_at IS DISTINCT FROM OLD.last_sync_at THEN
    NEW.sync_status = jsonb_build_object(
      'last_successful_sync', NEW.last_sync_at,
      'sync_count', COALESCE((OLD.sync_status->>'sync_count')::integer, 0) + 1
    );
  END IF;

  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_platform_connections_timestamps
  BEFORE UPDATE ON platform_connections
  FOR EACH ROW
  EXECUTE FUNCTION update_platform_connection_timestamps();

-- Create function to check and update expired connections
CREATE OR REPLACE FUNCTION check_connection_expiry()
RETURNS TRIGGER AS $$
BEGIN
  IF (NEW.config->>'expires_at')::bigint <= EXTRACT(EPOCH FROM NOW())::bigint * 1000 THEN
    NEW.status = 'expired';
  END IF;
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER check_platform_connections_expiry
  BEFORE INSERT OR UPDATE ON platform_connections
  FOR EACH ROW
  EXECUTE FUNCTION check_connection_expiry();

-- Add comments for documentation
COMMENT ON TABLE platform_connections IS 'Stores e-commerce platform integration configurations and status';
COMMENT ON COLUMN platform_connections.config IS 'Platform-specific configuration including auth tokens';
COMMENT ON COLUMN platform_connections.status IS 'Current connection status (active, inactive, error, expired)';
COMMENT ON COLUMN platform_connections.sync_status IS 'Sync operation statistics and status';
COMMENT ON COLUMN platform_connections.error_log IS 'Historical log of connection errors';
COMMENT ON COLUMN platform_connections.metadata IS 'Additional platform-specific metadata';